<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movie;
use App\Models\Show;

class ShowController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data1 = Movie::get();
    
        {
            $data = Show::Where('active','active')->paginate(5);
            //$data=Show::latest()->paginate(5);
            //$data = Show::Where('active','yes')->paginate(5);
            
        }

        return view('show.index',compact('data','data1'))->with('i',(request()->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = Movie::where('active','Yes')->get();
        return view('show.create',compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([

            'name' => 'required',
            'date' => 'required',
            'time' => 'required',
            'location' => 'required',
            // 'movie' => 'required',
            'active' => 'required',
        ]);

       
        $show=$request->all();

        Show::create($show);

        return redirect()->route('show.index')->with('success','Show Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Show $show)
    {
        $data = Movie::get();
        return view('show.edit',compact('show','data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Show $show)
    {
        $request->validate([
            'name' => 'required',
            'date' => 'required',
            'time' => 'required',
            'location' => 'required',
            'movie_id' => 'required',
            'active' => 'required',
        ],);
    
        $request_data = $request->all();
        $show->update($request_data);
        return redirect()->route('show.index')
                        ->with('success','show updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Show::find($id)->delete();
        return redirect()->route('show.index')->with('success','Show deleted successfully');
    }
}
