



<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Show</h2>
        </div>
        <div class="pull-right" style="float:right">
            <a class="btn btn-primary" href="<?php echo e(route('show.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('show.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Enter Name">
                <?php if($errors->has('name')): ?>
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Date:</strong>
                <input type="text" name="date" class="form-control" value="<?php echo e(old('date')); ?>" placeholder="Enter date">
                <?php if($errors->has('date')): ?>
                <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Time:</strong>
                <input type="text" name="time" class="form-control" value="<?php echo e(old('time')); ?>" placeholder="Enter time">
                <?php if($errors->has('time')): ?>
                <span class="text-danger"><?php echo e($errors->first('time')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Location:</strong>
                <input type="text" name="location" class="form-control" value="<?php echo e(old('location')); ?>" placeholder="Enter location">
                <?php if($errors->has('location')): ?>
                <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <br>
                <strong>Movie</strong>
                <select name="movie_id" class="form-control" id="movie_id">
                    <option value="">Select</option>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php if($errors->has('dropdown')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('dropdown')); ?></strong>
                </span>
            <?php endif; ?>
                </select>
                <span class="text-danger"></span>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Active:</strong>
                <select class="form-control" name="active">
                    <option value="">Select</option>
                    <option name="active" value="active">Active</option>
                    <option name="active" value="inactive">Inactive</option>
                </select>
                <?php if($errors->has('active')): ?>
                <span class="text-danger"><?php echo e($errors->first('active')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Movie\resources\views/show/create.blade.php ENDPATH**/ ?>