
<?php $__env->startSection('content'); ?>
<div class="container">

    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    </head>
    <div class="container">
        <div class="row" style="margin-top: 5rem;">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Show</h2>
                </div>
                <div>
                <div class="pull-right" style=" float : right;">
                <?php if(auth()->user()->usertype == '0'): ?>
                    <a class="btn btn-warning" href="movie">Movie</a>
                    <a class="btn btn-info" href="show">Show</a>
                <?php endif; ?>
                    <?php if(auth()->user()->usertype == '1'): ?>
                    <a class="btn btn-success" style="float:right;" href="show/create">Add New Show</a>
                    <a class="btn btn-info" style="float:right;  margin-right:5px;" href="<?php echo e(route('admin.index')); ?>"> User</a>
                    <a class="btn btn-warning" style="float:right;  margin-right:5px;" href="<?php echo e(route('movie.index')); ?>"> Movie</a>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr style="background-color: #4682B4">
            <th>No</th>
            <th>Show</th>
            <th>Movie</th>
            <th>Date</th>
            <th>Time</th>
            <th>Location</th>
            <th>Active</th>
            <th width="280px">Action</th>
        </tr>
        <tbody id="tbody">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->movie_id); ?></td>
                <td><?php echo e($value->date); ?></td>
                <td><?php echo e($value->time); ?></td>
                <td><?php echo e($value->location); ?></td>
                <td><?php echo e($value->active); ?></td>
                <td>

                <?php if(auth()->user()->usertype == '0'): ?>
                     <form action="" method="POST">
                        <a class="btn btn-success" href="">Book</a>
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
                     <?php if(auth()->user()->usertype == '1'): ?>
                    <form action="<?php echo e(route('show.destroy',$value->id)); ?>" method="POST">                        
                        <a class="btn btn-primary" href="<?php echo e(route('show.edit',$value->id)); ?>">Edit</a>                       
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger delete">Delete</button>
                      
                    </form>
                    <?php endif; ?>
                </td>
            </tr>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $data->links(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Movie\resources\views/show/index.blade.php ENDPATH**/ ?>