
<?php $__env->startSection('content'); ?>
 
<div class="container">

<div class="row" style="margin-top: 5rem;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-right">
            <h2>Home Page</h2>
        </div>
        <div class="pull-right" style=" float : right;">
          
        <?php if(auth()->user()->usertype == '0'): ?>
        <a class="btn btn-warning" href="movie">Movie</a>
        <a class="btn btn-info" href="show">Show</a>
        <?php endif; ?>
            <?php if(auth()->user()->usertype == '1'): ?>
            <a class="btn btn-success" href="admin/create"> Add New User</a>
            <a class="btn btn-info" href="movie/create"> Add Movie</a>
            <a class="btn btn-warning" href="show/create"> Movie Show</a>
            <?php endif; ?> 
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<table class="table table-bordered">
    <tr style="background-color: #4682B4">
        <th>No</th>
        <th>Name</th>
        <th>Email</th>
        
        <?php if(auth()->user()->usertype == '1'): ?>
        <th width="280px">Action</th>
        <?php endif; ?>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($value->name); ?></td>
        <td><?php echo e($value->email); ?></td>
      
        <?php if(auth()->user()->usertype == '1'): ?>
        <td>
            <form action="<?php echo e(route('admin.destroy',$value->id)); ?>" method="POST">
           
            <a class="btn btn-primary" href="<?php echo e(route('admin.edit',$value->id)); ?>">Edit</a>  
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                
                <button type="submit" class="btn btn-danger">Delete</button>
                <?php endif; ?>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>
</div>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Movie\resources\views/admin/index.blade.php ENDPATH**/ ?>