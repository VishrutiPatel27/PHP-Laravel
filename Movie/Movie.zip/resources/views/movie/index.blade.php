@extends('layouts.app')

@section('content')
<div class="container">

    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    </head>
    <div class="container">
        <div class="row" style="margin-top: 5rem;">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Moive</h2>
                </div>
                <div>
                    @if(auth()->user()->usertype == '1')

                    <a class="btn btn-success" style="float:right" href="movie/create">Add New Movie</a>
                    @endif
                    <a class="btn btn-info" style="float:right;  margin-right:5px;" href="{{ route('admin.index') }}">
                        User</a>


                </div>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
    <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
    @endif

    <table class="table table-bordered">
        <tr style="background-color: #4682B4">
            <th>No</th>
            <th>Name</th>
            <th>Description</th>
            <th>Small Image</th>
            <th>Big Image</th>
            <th>Active</th>
            <th width="280px">Action</th>
        </tr>
        <tbody id="tbody">
            @foreach($data as $key => $value)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $value->name }}</td>
                <td>{{ $value->description }}</td>
                <td><img src=" {{ asset('public/images/' . $value->simage)}}" width="50" height="30"></td>
                <td><img src=" {{ asset('public/images/' . $value->bimage)}}" width="100" height="80"></td>
                <td>{{ $value->active}}</td>
                <td>

                    @if(auth()->user()->usertype == '0')
                    <form action="" method="POST">
                        <a class="btn btn-success" href="">Book</a>
                        @csrf
                    </form>
                    @endif
                    @if(auth()->user()->usertype == '1')
                    <form action="{{ route('movie.destroy',$value->id) }}" method="POST">
                        <a class="btn btn-primary" href="{{ route('movie.edit',$value->id) }}">Edit</a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger delete">Delete</button>
                    </form>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    {!! $data->links() !!}

</div>
@endsection